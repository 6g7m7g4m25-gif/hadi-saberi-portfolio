const about = document.querySelector(".about");

window.addEventListener("scroll",()=>{

const position=about.getBoundingClientRect().top;

if(position<window.innerHeight-100){
    about.classList.add("show");
}

});